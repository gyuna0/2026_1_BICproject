`include "i2s_mic_test.v"
`timescale 1ns / 1ps

module TB_i2s_mic_test;

   // --- Inputs to DUT ---
   reg SYSCLK;
   reg RSTN;
   reg I2S_DATA;

   // --- Outputs from DUT ---
   wire	I2S_BCLK;
   wire	I2S_WS;
   wire [23:0] L_DATA;
   wire [23:0] R_DATA;
   wire	       DATA_DONE;

   // --- Test Data Patterns ---
   localparam [23:0] TEST_VAL_L = 24'hAB8000;
   localparam [23:0] TEST_VAL_R = 24'h124000;

   integer	     i;

   // --- DUT 인스턴스 ---
   i2s_mic_test uut (
		     .SYSCLK(SYSCLK), 
		     .RSTN(RSTN), 
		     .I2S_DATA(I2S_DATA), 
		     .I2S_BCLK(I2S_BCLK), 
		     .I2S_WS(I2S_WS), 
		     .L_DATA(L_DATA), 
		     .R_DATA(R_DATA), 
		     .DATA_DONE(DATA_DONE)
		     );

   // ==========================================
   // [추가됨] GTKWave용 VCD 파일 생성 코드
   // ==========================================
   initial begin
      // 시뮬레이션 결과를 'wave.vcd' 파일로 저장
      $dumpfile("TB_i2s_mic_test.vcd");
      
      // tb_i2s_mic_test 모듈 내부의 모든 신호(Level 0)를 덤프
      $dumpvars(0, TB_i2s_mic_test);
   end
   // ==========================================

   // --- 12MHz 시스템 클럭 생성 ---
   initial begin
      SYSCLK = 0;
      forever #41.667 SYSCLK = ~SYSCLK;
   end

   // --- 리셋 및 시뮬레이션 제어 ---
   initial begin
      RSTN = 0;
      I2S_DATA = 0;

      #200;
      RSTN = 1;
      $display("Reset Released. Starting I2S Communication...");

      // 충분한 시간 동안 시뮬레이션
      #300000; 
      
      $display("Simulation Finished.");
      $finish;
   end

   // --- 마이크 동작 에뮬레이션 (Mock Microphone) ---
   always @(negedge I2S_WS) begin
      @(negedge I2S_BCLK); // 1-bit Delay (Padding)
      
      for (i = 23; i >= 0; i = i - 1) begin
         I2S_DATA <= TEST_VAL_L[i];
         @(negedge I2S_BCLK);
      end
      I2S_DATA <= 0;
   end

   // [Right Channel]
   always @(posedge I2S_WS) begin
      @(negedge I2S_BCLK); // 1-bit Delay (Padding)
      
      for (i = 23; i >= 0; i = i - 1) begin
         I2S_DATA <= TEST_VAL_R[i];
         @(negedge I2S_BCLK);
      end
      I2S_DATA <= 0;
   end

   // --- 결과 모니터링 ---
   always @(posedge SYSCLK) begin
      if (DATA_DONE) begin
         $display("[Time: %0t] Data Received! L: %h, R: %h", $time, L_DATA, R_DATA);
      end
   end

endmodule
