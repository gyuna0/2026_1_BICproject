module i2s_mic_test(
		     input wire	       SYSCLK, // cmod 12MHz
		     input wire	       RSTN,
		     input wire	       I2S_DATA,
		     output reg	       I2S_BCLK,
		     output reg	       I2S_WS,
		     output reg [23:0] L_DATA,
		     output reg [23:0] R_DATA,
		     output reg	DATA_DONE
		    );

   parameter CLK_DIV = 2;

   reg [2:0] div_cnt;
   reg	     bclk_rise;
   reg [5:0] bit_cnt; //left 32 bit, right 32bit(WS는 BCLK의 1/64) 
   reg [23:0] shift_reg;

   //combinational reg
   reg [2:0]  div_cnt_next;
   reg        I2S_BCLK_next;
   reg        bclk_rise_next;
   
   reg [5:0]  bit_cnt_next;
   reg        I2S_WS_next;
   reg [23:0] shift_reg_next;
   reg [23:0] L_DATA_next;
   reg [23:0] R_DATA_next;
   reg        DATA_DONE_next;

   //sequential logic
   always @(posedge SYSCLK or negedge RSTN) begin
      if (!RSTN) begin
         div_cnt    <= 0;
         I2S_BCLK   <= 0; // 초기값 Low
         bclk_rise  <= 0;
         
         bit_cnt    <= 0;
         I2S_WS     <= 0; // 초기값 Low (Left)
         shift_reg  <= 0;
         L_DATA     <= 0;
         R_DATA     <= 0;
         DATA_DONE  <= 0;
      end else begin
         div_cnt    <= div_cnt_next;
         I2S_BCLK   <= I2S_BCLK_next;
         bclk_rise  <= bclk_rise_next;
         
         bit_cnt    <= bit_cnt_next;
         I2S_WS     <= I2S_WS_next;
         shift_reg  <= shift_reg_next;
         L_DATA     <= L_DATA_next;
         R_DATA     <= R_DATA_next;
         DATA_DONE  <= DATA_DONE_next;
      end
   end // always @ (posedge SYSCLK or negedge RSTN)

   always @(*) begin
      div_cnt_next   = div_cnt;
      I2S_BCLK_next  = I2S_BCLK;
      bclk_rise_next = 0; 

      bit_cnt_next   = bit_cnt;
      I2S_WS_next    = I2S_WS;
      shift_reg_next = shift_reg;
      L_DATA_next    = L_DATA;
      R_DATA_next    = R_DATA;
      DATA_DONE_next = 0;

      //BCLK 생성 (3MHz)
      if (div_cnt == CLK_DIV -1 ) begin
	 div_cnt_next = 0;
	 I2S_BCLK_next = ~I2S_BCLK;

	 if(I2S_BCLK == 0) begin
	    bclk_rise_next = 1; //rise edge 검출 
	 end
      end else begin
	 div_cnt_next = div_cnt + 1;
      end

      //I2S 데이터 처리 로직(neg에서 데이터 전송 -> rise에서 처리)
      if(bclk_rise) begin
	 bit_cnt_next = bit_cnt +1;

	 if(bit_cnt == 31) begin
	   I2S_WS_next = 1; //WS high
	 end
	 else if ( bit_cnt == 63) begin
	   I2S_WS_next = 0; //WS low
	 end

	 //Left data: WS 변하고 1clk 후에 
	 if(bit_cnt >= 1 && bit_cnt <= 24) begin
	    shift_reg_next = {shift_reg[22:0], I2S_DATA};
	 end

	 //Right data
	 else if (bit_cnt >= 32 && bit_cnt <= 55) begin
	    shift_reg_next = {shift_reg[22:0], I2S_DATA};
	 end

	 if(bit_cnt == 31) begin
	    L_DATA_next = shift_reg;
	 end
	 else if (bit_cnt == 63) begin
	    R_DATA_next = shift_reg;
	    DATA_DONE_next =1;
	 end
      end // if (bclk_rise)
   end // always @ (*)

endmodule // i2s_mic_test

      
	 
   
