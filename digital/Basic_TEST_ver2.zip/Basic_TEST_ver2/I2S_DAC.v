module I2S_DAC(
        input wire        RSTN,
        input wire        BCK,
        input wire [23:0] L_DATA_IN,
        input wire [23:0] R_DATA_IN,
        output reg DAC_LRCK,
        output reg DAC_DIN
       );

   reg [5:0] bit_cnt;
   reg [23:0] shift_reg;
   reg [23:0] latched_R;

   reg [5:0]  bit_cnt_next;
   reg [23:0] shift_reg_next;
   reg [23:0] latched_R_next;
   reg        DAC_LRCK_next;
   reg        DAC_DIN_next;

   always @(negedge BCK or negedge RSTN) begin
      if (!RSTN) begin
         bit_cnt   <= 0;
         shift_reg <= 0;
         latched_R <= 0;
         DAC_LRCK  <= 0;
         DAC_DIN   <= 0;
      end else begin
         bit_cnt   <= bit_cnt_next;
         shift_reg <= shift_reg_next;
         latched_R <= latched_R_next;
         DAC_LRCK  <= DAC_LRCK_next;
         DAC_DIN   <= DAC_DIN_next;
      end
   end

   always @(*) begin
      bit_cnt_next   = bit_cnt;
      shift_reg_next = shift_reg;
      latched_R_next = latched_R;
      DAC_LRCK_next  = DAC_LRCK;
      DAC_DIN_next   = DAC_DIN;

      if (bit_cnt == 63) 
        bit_cnt_next = 0;
      else 
        bit_cnt_next = bit_cnt + 1;

      // [������] �ø��÷��� 1Ŭ�� ������ �����Ͽ� 63, 31���� �̸� �����ϵ��� �ѹ�
      if (bit_cnt == 63)       
        DAC_LRCK_next = 0;
      else if (bit_cnt == 31) 
        DAC_LRCK_next = 1;

      if (bit_cnt == 0) begin
         shift_reg_next = {L_DATA_IN[22:0], 1'b0};
         latched_R_next = R_DATA_IN;
         DAC_DIN_next   = L_DATA_IN[23];
      end
      else if (bit_cnt == 32) begin
         shift_reg_next = {latched_R[22:0], 1'b0};
         DAC_DIN_next   = latched_R[23]; 
      end
    
      else if ((bit_cnt >= 1 && bit_cnt <= 23) || (bit_cnt >= 33 && bit_cnt <= 55)) begin
         DAC_DIN_next   = shift_reg[23];
         shift_reg_next = {shift_reg[22:0], 1'b0};
      end
      else begin
         DAC_DIN_next = 0;
      end
   end
      
endmodule