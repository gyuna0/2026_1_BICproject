module I2S_MIC(
    input wire        RSTN,
    input wire        BCLK,  // Top���� ������ Ŭ��
    input wire        MIC_DATA_IN,
    
    output reg        MIC_WS,
    output reg [23:0] L_DATA,
    output reg [23:0] R_DATA,
    output reg        DATA_DONE
    );

    reg [5:0] bit_cnt; 
    reg [23:0] shift_reg;

    // Next State Variables
    reg [5:0]  bit_cnt_next;
    reg        MIC_WS_next;
    reg [23:0] shift_reg_next;
    reg [23:0] L_DATA_next;
    reg [23:0] R_DATA_next;
    reg        DATA_DONE_next;

    // Sequential Logic
    always @(posedge BCLK or negedge RSTN) begin
        if (!RSTN) begin
            bit_cnt    <= 0;
            MIC_WS     <= 0;
            shift_reg  <= 0;
            L_DATA     <= 0;
            R_DATA     <= 0;
            DATA_DONE  <= 0;
        end else begin
            bit_cnt    <= bit_cnt_next;
            MIC_WS     <= MIC_WS_next;
            shift_reg  <= shift_reg_next;
            L_DATA     <= L_DATA_next;
            R_DATA     <= R_DATA_next;
            DATA_DONE  <= DATA_DONE_next;
        end
    end

    // Combinational Logic
    always @(*) begin
        bit_cnt_next   = bit_cnt;
        MIC_WS_next    = MIC_WS;
        shift_reg_next = shift_reg;
        L_DATA_next    = L_DATA;
        R_DATA_next    = R_DATA;
        DATA_DONE_next = 0;
        
        // Counter
        if (bit_cnt == 63) 
            bit_cnt_next = 0;
        else 
            bit_cnt_next = bit_cnt + 1;
        
        // WS Generation
        if (bit_cnt == 31) 
            MIC_WS_next = 1; // WS high (Right)
        else if (bit_cnt == 63) 
            MIC_WS_next = 0; // WS low (Left)

      
        if (bit_cnt >= 0 && bit_cnt <= 23) begin
            shift_reg_next = {shift_reg[22:0], MIC_DATA_IN};
        end
        else if (bit_cnt >= 32 && bit_cnt <= 55) begin
            shift_reg_next = {shift_reg[22:0], MIC_DATA_IN};
        end

        // Data Latch
        if (bit_cnt == 31) begin
            L_DATA_next = shift_reg;
        end
        else if (bit_cnt == 63) begin
            R_DATA_next = shift_reg;
            DATA_DONE_next = 1;
        end
    end

endmodule