module TOP_TEST (
    input wire RST,
    input wire SYSCLK,        
    
    input wire MIC_DATA_IN,     
    output wire MIC_WS,
    
    output wire DAC_SCK,    
    output wire DAC_LRCK,  
    output wire DAC_DATA_OUT, 
    output wire DAC_BCK,    
    
    output wire MIC_BCLK
);

    wire clk_6m;
    wire locked;
    reg clk_div_reg;
    wire clk_3m;
    wire I2S_BCLK;
    wire RSTN;
    
    
    assign RSTN = locked & (!RST);
    assign I2S_BCLK = clk_3m;
    assign MIC_BCLK = I2S_BCLK;
    assign DAC_BCK = I2S_BCLK;
    assign DAC_SCK = 1'b0; //BCK ��� 
    
    clk_wiz_0 u_clk_gen(
        .clk_out1(clk_6m),
        .reset(RST),
        .locked(locked),
        .clk_in1(SYSCLK)
        );
        
    always @(posedge clk_6m or posedge RST) begin
        if (RST) 
            clk_div_reg <= 0;
        else 
            clk_div_reg <= ~clk_div_reg;
    end
    
    BUFG u_bufg_i2s (
        .I(clk_div_reg), 
        .O(clk_3m)   
    );
    
    
    
    // ���� ����� Wires
    wire [23:0] mic_l_data;
    wire [23:0] mic_r_data;
    wire        mic_data_done;

    wire [23:0] dac_l_data;
    wire [23:0] dac_r_data;


    // ---------------------------------------------------------
    // 1. I2S Input (Mic_SPH)
    // ---------------------------------------------------------
    I2S_MIC u_mic (
        .RSTN(RSTN),
        .BCLK(MIC_BCLK),
        .MIC_DATA_IN(MIC_DATA_IN),
        .MIC_WS(MIC_WS),
        .L_DATA(mic_l_data),
        .R_DATA(mic_r_data),
        .DATA_DONE(mic_data_done)
    );

    // ---------------------------------------------------------
    // 2. Path A Processing (Inverting Core)
    // ---------------------------------------------------------
    TEST_basic u_path_a (
        .RSTN(RSTN),
        .I2S_BCLK(I2S_BCLK),
        .DATA_VALID(mic_data_done),
        .L_DATA_IN(mic_l_data),
        .R_DATA_IN(mic_r_data),
        .L_DATA_OUT(dac_l_data),
        .R_DATA_OUT(dac_r_data)
    );

    // ---------------------------------------------------------
    // 3. I2S Output (DAC_PCM)
    // ---------------------------------------------------------
    I2S_DAC u_dac (
        .RSTN(RSTN),
        .BCK(DAC_BCK),
        .L_DATA_IN(dac_l_data),
        .R_DATA_IN(dac_r_data),
        
        .DAC_LRCK(DAC_LRCK),
        .DAC_DIN(DAC_DATA_OUT)
    );

endmodule