module TOP_MLP(
    input wire CLK,               // �ý��� Ŭ��
    input wire RSTN,              // ���� (Active Low)
    input wire signed [15:0] DATA_IN, // �Է� ������
    input wire MLP_DATA_VALID,        // ������ ��ȿ ��ȣ
    input wire [5:0] MLP_IDX,         // ������ ��ȣ (0~63)
    
    output reg IS_DANGER          // ���: 1=���̷�(����), 0=����
    );

    // =========================================================================
    // 1. ���� �޸� �� ��������
    // =========================================================================
    reg signed [15:0] ram_ping [0:127]; 
    reg signed [15:0] ram_pong [0:127]; 
    
    // [����] �迭 �����ϰ� Ȯ���� �������� ���� ���
    reg signed [31:0] score_danger; // Danger ���� �����
    reg signed [15:0] bias_reg;     // Bias �� ����ȭ�� ����

    // �ʱ�ȭ
    integer k;
    initial begin
        for(k=0; k<128; k=k+1) begin
            ram_ping[k] = 16'd0;
            ram_pong[k] = 16'd0;
        end
        score_danger = 0; 
        bias_reg = 0;
        IS_DANGER = 0;
    end
    
    // =========================================================================
    // 2. BRAM IP ����
    // =========================================================================
    reg [12:0] addr_l1_w=0; reg [6:0] addr_l1_b=0; wire signed [15:0] q_l1_w, q_l1_b;
    reg [12:0] addr_l2_w=0; reg [6:0] addr_l2_b=0; wire signed [15:0] q_l2_w, q_l2_b;
    reg [11:0] addr_l3_w=0; reg [5:0] addr_l3_b=0; wire signed [15:0] q_l3_w, q_l3_b;
    reg [5:0]  addr_l4_w=0; reg [4:0] addr_l4_b=0; wire signed [15:0] q_l4_w, q_l4_b;

    // IP �ν��Ͻ�ȭ 
    BRAM_L1_w u_l1_w (.clka(CLK), .ena(RSTN), .addra(addr_l1_w), .douta(q_l1_w));
    BRAM_L1_b u_l1_b (.clka(CLK), .ena(RSTN), .addra(addr_l1_b), .douta(q_l1_b));
    
    BRAM_L2_w u_l2_w (.clka(CLK), .ena(RSTN), .addra(addr_l2_w), .douta(q_l2_w));
    BRAM_L2_b u_l2_b (.clka(CLK), .ena(RSTN), .addra(addr_l2_b), .douta(q_l2_b));
    
    BRAM_L3_w u_l3_w (.clka(CLK), .ena(RSTN), .addra(addr_l3_w), .douta(q_l3_w));
    BRAM_L3_b u_l3_b (.clka(CLK), .ena(RSTN), .addra(addr_l3_b), .douta(q_l3_b));
    
    BRAM_L4_w u_l4_w (.clka(CLK), .ena(RSTN), .addra(addr_l4_w), .douta(q_l4_w));
    BRAM_L4_b u_l4_b (.clka(CLK), .ena(RSTN), .addra(addr_l4_b), .douta(q_l4_b));

    // =========================================================================
    // 3. ���� �ӽ� (FSM)
    // =========================================================================
    localparam S_IDLE       = 0; 
    localparam S_L1_CALC    = 1;
    localparam S_L2_CALC    = 2;
    localparam S_L3_CALC    = 3;
    localparam S_L4_CALC    = 4;
    localparam S_DECIDE     = 5; // ���� �Ǵ�
    localparam S_DONE       = 6;

    reg [3:0] state;
    
    // ���� ����
    reg [7:0] cnt_neuron=0; 
    reg [7:0] cnt_weight=0; 
    reg [3:0] wait_cycle=0; 

    // ���� ����
    reg signed [47:0] accumulator=0; 
    reg signed [15:0] mac_input_val=0;
    reg signed [15:0] mac_weight_val=0;
    reg signed [31:0] mult_result=0;
    reg signed [47:0] temp_sum=0;

    // =========================================================================
    // 4. ���� ����
    // =========================================================================
    always @(posedge CLK or negedge RSTN) begin
        if (!RSTN) begin
            state <= S_IDLE;
            IS_DANGER <= 0;
            score_danger <= 0;
            cnt_neuron <= 0; 
            cnt_weight <= 0;
            accumulator <= 0; 
            wait_cycle <= 0; 
            temp_sum <= 0;
            bias_reg <= 0;
            
            addr_l1_w <= 0; addr_l1_b <= 0;
            addr_l2_w <= 0; addr_l2_b <= 0;
            addr_l3_w <= 0; addr_l3_b <= 0;
            addr_l4_w <= 0; addr_l4_b <= 0;
            mult_result <= 0;
            
        end else begin
            case (state)
                S_IDLE: begin
                    if (MLP_DATA_VALID) begin
                        ram_ping[MLP_IDX] <= DATA_IN; 
                        
                        if (MLP_IDX == 63) begin        
                            state <= S_L1_CALC;        
                            cnt_neuron <= 0; cnt_weight <= 0; accumulator <= 0; wait_cycle <= 0;
                            addr_l1_w <= 0; addr_l1_b <= 0; 
                        end
                    end
                end

                // [Layer 1]
                S_L1_CALC: begin
                    addr_l1_w <= (cnt_neuron * 64) + cnt_weight;
                    addr_l1_b <= cnt_neuron;
                    
                    if (wait_cycle < 2) begin
                        wait_cycle <= wait_cycle + 1;
                    end else begin
                        mac_weight_val = q_l1_w;            
                        mac_input_val = ram_ping[cnt_weight]; 
                        
                        if ((mac_weight_val === 16'bx) || (mac_input_val === 16'bx)) mult_result = 0;
                        else mult_result = mac_input_val * mac_weight_val;

                        accumulator <= accumulator + mult_result;
                        
                        if (cnt_weight < 63) begin
                            cnt_weight <= cnt_weight + 1;
                            wait_cycle <= 0; 
                        end else begin
                            // Bias & ReLU
                            if (q_l1_b === 16'bx) temp_sum = (accumulator >>> 10);
                            else temp_sum = (accumulator >>> 10) + q_l1_b; 
                            
                            if (temp_sum < 0) ram_pong[cnt_neuron] <= 0; 
                            else if (temp_sum > 32767) ram_pong[cnt_neuron] <= 32767;
                            else ram_pong[cnt_neuron] <= temp_sum[15:0];
                            
                            if (cnt_neuron < 127) begin
                                cnt_neuron <= cnt_neuron + 1;
                                cnt_weight <= 0; accumulator <= 0; wait_cycle <= 0;
                            end else begin
                                state <= S_L2_CALC;
                                cnt_neuron <= 0; cnt_weight <= 0; accumulator <= 0; wait_cycle <= 0;
                            end
                        end
                    end
                end

                // [Layer 2]
                S_L2_CALC: begin
                    addr_l2_w <= (cnt_neuron * 128) + cnt_weight;
                    addr_l2_b <= cnt_neuron;
                    
                    if (wait_cycle < 2) begin
                        wait_cycle <= wait_cycle + 1;
                    end else begin
                        mac_weight_val = q_l2_w;
                        mac_input_val = ram_pong[cnt_weight]; 
                        
                        if ((mac_weight_val === 16'bx) || (mac_input_val === 16'bx)) mult_result = 0;
                        else mult_result = mac_input_val * mac_weight_val;

                        accumulator <= accumulator + mult_result;
                        
                        if (cnt_weight < 127) begin
                            cnt_weight <= cnt_weight + 1;
                            wait_cycle <= 0;
                        end else begin
                            if (q_l2_b === 16'bx) temp_sum = (accumulator >>> 10);
                            else temp_sum = (accumulator >>> 10) + q_l2_b;
                            
                            if (temp_sum < 0) ram_ping[cnt_neuron] <= 0;
                            else if (temp_sum > 32767) ram_ping[cnt_neuron] <= 32767;
                            else ram_ping[cnt_neuron] <= temp_sum[15:0];
                            
                            if (cnt_neuron < 63) begin
                                cnt_neuron <= cnt_neuron + 1;
                                cnt_weight <= 0; accumulator <= 0; wait_cycle <= 0;
                            end else begin
                                state <= S_L3_CALC;
                                cnt_neuron <= 0; cnt_weight <= 0; accumulator <= 0; wait_cycle <= 0;
                            end
                        end
                    end
                end

                // [Layer 3]
                S_L3_CALC: begin
                    addr_l3_w <= (cnt_neuron * 64) + cnt_weight;
                    addr_l3_b <= cnt_neuron;
                    
                    if (wait_cycle < 2) wait_cycle <= wait_cycle + 1;
                    else begin
                        mac_weight_val = q_l3_w;
                        mac_input_val = ram_ping[cnt_weight]; 
                        
                        if ((mac_weight_val === 16'bx) || (mac_input_val === 16'bx)) mult_result = 0;
                        else mult_result = mac_input_val * mac_weight_val;

                        accumulator <= accumulator + mult_result;
                        
                        if (cnt_weight < 63) begin
                            cnt_weight <= cnt_weight + 1;
                            wait_cycle <= 0;
                        end else begin
                            if (q_l3_b === 16'bx) temp_sum = (accumulator >>> 10);
                            else temp_sum = (accumulator >>> 10) + q_l3_b;
                            
                            if (temp_sum < 0) ram_pong[cnt_neuron] <= 0;
                            else if (temp_sum > 32767) ram_pong[cnt_neuron] <= 32767;
                            else ram_pong[cnt_neuron] <= temp_sum[15:0];
                            
                            if (cnt_neuron < 31) begin
                                cnt_neuron <= cnt_neuron + 1;
                                cnt_weight <= 0; accumulator <= 0; wait_cycle <= 0;
                            end else begin
                                state <= S_L4_CALC;
                                cnt_neuron <= 0; cnt_weight <= 0; accumulator <= 0; wait_cycle <= 0;
                            end
                        end
                    end
                end

                // =============================================================
                // [Layer 4] - Output Layer (���� �Ϸ�: ������ ������ ĸó)
                // =============================================================
       
                S_L4_CALC: begin
                    // �ּ� ���� (0~31�� ������)
                    if (cnt_weight < 32) begin
                        addr_l4_w <= (cnt_neuron * 32) + cnt_weight; 
                        addr_l4_b <= cnt_neuron;             
                    end
                    
                    if (wait_cycle < 2) begin 
                        wait_cycle <= wait_cycle + 1;
                    end else begin
                        // [1] Bias �� ĸó
                        bias_reg <= q_l4_b;

                        // [2] MAC ���� ���� (0 ~ 31)
                        if (cnt_weight < 32) begin
                            mac_weight_val = q_l4_w;
                            mac_input_val = ram_pong[cnt_weight]; 
                            
                            if ((mac_weight_val === 16'bx) || (mac_input_val === 16'bx)) mult_result = 0;
                            else mult_result = mac_input_val * mac_weight_val;

                            accumulator <= accumulator + mult_result;
                            cnt_weight <= cnt_weight + 1;
                            wait_cycle <= 0; 
                        end 
                        // [3] ���� ���� (cnt_weight == 32)
                        else begin
                            // temp_sum ���
                            if (bias_reg === 16'bx) temp_sum <= (accumulator >>> 10);
                            else temp_sum <= (accumulator >>> 10) + bias_reg;
                            
                            // �� [�ٽ� ����] ���ǹ� ����! ������ ���� ��
                            // 0�� ������ ���� ����ǰ�, 1�� ������ �� ��������ϴ�.
                            // �ᱹ �������� ���� �� 1��(Danger) ���� �˴ϴ�.
                            score_danger <= temp_sum;
                            
                            // ���� �ܰ� �̵� ����
                            if (cnt_neuron < 1) begin
                                cnt_neuron <= cnt_neuron + 1;
                                cnt_weight <= 0; 
                                accumulator <= 0; 
                                wait_cycle <= 0;
                            end else begin
                                state <= S_DECIDE; 
                            end
                        end
                    end
                end

                // [���� �Ǵ�] - ����� score_danger ���� ���
                S_DECIDE: begin
                    // score_danger�� ���������̹Ƿ� ���°� ���ص� �� ������
                    if (score_danger > 100) begin
                        IS_DANGER <= 1;
                    end else begin
                        IS_DANGER <= 0;
                    end
                    
                    state <= S_DONE;
                end

                S_DONE: begin
                    state <= S_IDLE; 
                end
                
                default: state <= S_IDLE;
            endcase
        end
    end

endmodule