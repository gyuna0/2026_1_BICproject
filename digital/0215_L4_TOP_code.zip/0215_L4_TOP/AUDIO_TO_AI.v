module AUDIO_TO_AI(
    input wire        CLK,              
    input wire        RSTN,             
    
    // [1] ����ũ �Է�
    input wire [23:0] MIC_DATA,         
    input wire        MIC_VALID,        
    
    // [2] AI ���
    output wire [15:0] AI_INPUT_DATA,   
    output reg          AI_INPUT_VALID, 
    output reg [5:0]    AI_INPUT_IDX    
    );
    
    // =============================================================
    // 1. ���� �ӽ� �� ����
    // =============================================================
    localparam S_IDLE       = 3'd0; 
    localparam S_COLLECT    = 3'd1; 
    localparam S_RUN_FFT    = 3'd3; 
    localparam S_CALC_MAG   = 3'd4; 
    
    reg [2:0] state = S_IDLE; 
    reg [8:0] cnt = 0; 
    
    reg [15:0] audio_buffer [0:255]; 
    integer i; 

    initial begin
        for (i = 0; i < 256; i = i + 1) audio_buffer[i] = 16'd0; 
    end
    
    // =============================================================
    // 2. FFT ���� ��ȣ
    // =============================================================
    wire fft_ready;
    wire [31:0] fft_out_data;
    wire fft_out_valid;
    wire last_missing; // tlast �����
    
    // Config: Forward Mode (ģ�� �ڵ� ��Ÿ��: �׻� 1)
    wire [7:0] cfg_data = 8'b0000_0001; 
    wire       cfg_valid = 1'b1; 

    wire fft_start_valid = (state == S_RUN_FFT);
    wire fft_in_last     = (state == S_RUN_FFT) && (cnt == 255);

    // =============================================================
    // 3. Magnitude & CORDIC ����
    // =============================================================
    wire signed [15:0] fft_real = fft_out_data[15:0];
    wire signed [15:0] fft_imag = fft_out_data[31:16];
    
    reg [31:0] mag_sq_sum = 0;      
    wire [15:0] mag_sqrt;  
    wire [16:0] mag_sqrt_raw;
    assign AI_INPUT_DATA = mag_sqrt_raw[15:0];       
    
    reg  cordic_input_valid = 0;    
    wire cordic_out_valid;
    
    // =============================================================
    // 4. ���� ���� �ӽ� (FSM)
    // =============================================================
    always @(posedge CLK or negedge RSTN) begin
        if (!RSTN) begin
            state <= S_IDLE;
            cnt <= 0;
            AI_INPUT_VALID <= 0;
            AI_INPUT_IDX <= 0;
        end else begin
            case (state)
                S_IDLE: begin
                    AI_INPUT_VALID <= 0;
                    AI_INPUT_IDX <= 0;
                    cnt <= 0;
                    if (MIC_VALID) begin
                        audio_buffer[0] <= MIC_DATA[23:8]; 
                        cnt <= 1;
                        state <= S_COLLECT;
                    end
                end
                
                S_COLLECT: begin
                    if (MIC_VALID) begin
                        audio_buffer[cnt] <= MIC_DATA[23:8];
                        cnt <= cnt + 1;
                        if (cnt == 255) begin
                            state <= S_RUN_FFT; 
                            cnt <= 0;
                        end
                    end
                end
                
                S_RUN_FFT: begin
                    if (fft_ready) begin
                        cnt <= cnt + 1;
                        if (cnt == 255) begin
                            state <= S_CALC_MAG;
                            cnt <= 0;
                        end
                    end
                end
                
                S_CALC_MAG: begin
                    if (cordic_out_valid) begin
                        if (cnt < 64) begin
                            AI_INPUT_VALID <= 1;
                            AI_INPUT_IDX <= cnt[5:0];
                            cnt <= cnt + 1;
                        end else begin
                            AI_INPUT_VALID <= 0;
                            state <= S_IDLE; 
                        end
                    end else begin
                        AI_INPUT_VALID <= 0;
                    end
                end
                
                default: state <= S_IDLE;
            endcase
        end
    end

    // =============================================================
    // 5. ���������� (������)
    // =============================================================
    always @(posedge CLK or negedge RSTN) begin
        if (!RSTN) begin
            mag_sq_sum <= 0;
            cordic_input_valid <= 0;
        end else begin
            if (fft_out_valid) begin
                mag_sq_sum <= (fft_real * fft_real) + (fft_imag * fft_imag);
            end
            cordic_input_valid <= fft_out_valid; 
        end
    end

    // =============================================================
    // 6. IP �ν��Ͻ�ȭ (VEO ��Ʈ �Ϻ� �ݿ�)
    // =============================================================
    
    xfft_0 u_fft (
        .aclk(CLK),                                           // input wire aclk
        
        // [Configuration Channel]
        .s_axis_config_tdata(cfg_data),                       // input wire [7 : 0] s_axis_config_tdata
        .s_axis_config_tvalid(cfg_valid),                     // input wire s_axis_config_tvalid
        .s_axis_config_tready(),                              // output wire s_axis_config_tready (�Ⱦ�)
        
        // [Data Input Channel]
        .s_axis_data_tdata({16'd0, audio_buffer[cnt]}),       // input wire [31 : 0] s_axis_data_tdata
        .s_axis_data_tvalid(fft_start_valid),                 // input wire s_axis_data_tvalid
        .s_axis_data_tready(fft_ready),                       // output wire s_axis_data_tready
        .s_axis_data_tlast(fft_in_last),                      // input wire s_axis_data_tlast
        
        // [Data Output Channel]
        .m_axis_data_tdata(fft_out_data),                     // output wire [31 : 0] m_axis_data_tdata
        .m_axis_data_tuser(),                                 // output wire [7 : 0] m_axis_data_tuser (�Ⱦ�)
        .m_axis_data_tvalid(fft_out_valid),                   // output wire m_axis_data_tvalid
        .m_axis_data_tready(1'b1),                            // input wire m_axis_data_tready (�׻� �غ�)
        .m_axis_data_tlast(last_missing),                     // output wire m_axis_data_tlast
        
        // [Status Channel - �� ������ ���� ������ ����]
        .m_axis_status_tdata(),                               // output wire [7 : 0] m_axis_status_tdata
        .m_axis_status_tvalid(),                              // output wire m_axis_status_tvalid
        .m_axis_status_tready(1'b1),                          // input wire m_axis_status_tready (Ȥ�� �𸣴� �׻� �غ�)
        
        // [Events - �� ��]
        .event_frame_started(),                               // output wire event_frame_started
        .event_tlast_unexpected(),                            // output wire event_tlast_unexpected
        .event_tlast_missing(),                               // output wire event_tlast_missing
        .event_status_channel_halt(),                         // output wire event_status_channel_halt
        .event_data_in_channel_halt(),                        // output wire event_data_in_channel_halt
        .event_data_out_channel_halt()                        // output wire event_data_out_channel_halt
    );
    

    // [CORDIC IP] (Sqrt)
    cordic_0 u_cordic (
        .aclk(CLK),
        
        // [����] .aresetn(RSTN) -- IP �������� ���������Ƿ� ����
        
        .s_axis_cartesian_tvalid(cordic_input_valid),
        .s_axis_cartesian_tdata(mag_sq_sum), 
        
        .m_axis_dout_tvalid(cordic_out_valid),
        .m_axis_dout_tdata(mag_sqrt_raw)
    );

endmodule