module TOP_noninver (
    input wire RST,
    input wire SYSCLK,           // �ý��� ������ Ŭ�� (12MHz)
    input wire DATA_IN,      // [MIC] Data In

    output wire I2S_MCLK_OUT,    // [Audio Chip] MCLK
    output wire I2S_BCLK_OUT,    // [Audio Chip] BCLK
    output wire I2S_WS_MIC,      // [MIC] WS
    output wire I2S_WS_DAC,      // [DAC] WS
    output wire I2S_DATA_TX      // [DAC] Data Out
);

    wire clk_6m;
    wire locked;
    reg clk_div_reg;
    wire clk_3m;
    
    wire I2S_BCLK;
    
    clk_wiz_0 u_clk_gen(
        .clk_out1(clk_6m),
        .reset(RST),
        .locked(locked),
        .clk_in1(SYSCLK)
        );
        
    always @(posedge clk_6m or posedge RST) begin
        if (RST) 
            clk_div_reg <= 0;
        else 
            clk_div_reg <= ~clk_div_reg;
    end
    
    BUFG u_bufg_i2s (
        .I(clk_div_reg), 
        .O(clk_3m)   
    );
    
    wire RSTN;
    assign RSTN = locked & (!RST);
    assign I2S_BCLK = clk_3m;
    assign I2S_MCLK_OUT = SYSCLK;
    
    // ���� ����� Wires
    wire [23:0] mic_l_data;
    wire [23:0] mic_r_data;
    wire        mic_data_done;

    wire [23:0] dac_l_data;
    wire [23:0] dac_r_data;

    // Ŭ�� �Ҵ�
    assign I2S_BCLK_OUT = I2S_BCLK;

    // ---------------------------------------------------------
    // 1. I2S Input (Microphone)
    // ---------------------------------------------------------
    I2S_MIC u_mic (
        .RSTN(RSTN),
        .I2S_BCLK_IN(I2S_BCLK),
        .I2S_DATA(DATA_IN),
        
        .I2S_BCLK_OUT(),          // Open
        .I2S_WS(I2S_WS_MIC),
        .L_DATA(mic_l_data),
        .R_DATA(mic_r_data),
        .DATA_DONE(mic_data_done)
    );

    // ---------------------------------------------------------
    // 2. Path A Processing (Inverting Core)
    // ---------------------------------------------------------
    non_inverting u_path_a (
        .RSTN(RSTN),
        .I2S_BCLK(I2S_BCLK),
        .DATA_VALID(mic_data_done),
        .L_DATA_IN(mic_l_data),
        .R_DATA_IN(mic_r_data),
        
        .L_DATA_OUT(dac_l_data),
        .R_DATA_OUT(dac_r_data)
    );

    // ---------------------------------------------------------
    // 3. I2S Output (DAC / Speaker)
    // ---------------------------------------------------------
    I2S_DAC u_dac (
        .RSTN(RSTN),
        .I2S_BCLK(I2S_BCLK),
        .L_DATA_IN(dac_l_data),
        .R_DATA_IN(dac_r_data),
        
        .I2S_LRCK(I2S_WS_DAC),
        .I2S_DIN(I2S_DATA_TX)
    );

endmodule