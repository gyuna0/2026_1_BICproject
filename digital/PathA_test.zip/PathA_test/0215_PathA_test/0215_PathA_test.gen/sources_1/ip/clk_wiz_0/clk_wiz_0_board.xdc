#--------------------Physical Constraints-----------------

